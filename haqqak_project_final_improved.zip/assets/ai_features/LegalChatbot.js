// ميزات الذكاء الاصطناعي - روبوت المحادثة القانوني
import React, { useState, useEffect, useRef } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TextInput, 
  TouchableOpacity, 
  KeyboardAvoidingView, 
  Platform,
  ActivityIndicator,
  ScrollView
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { API_URL } from '../../config';
import { useAuth } from '../../contexts/AuthContext';
import ChatBubble from '../../components/Chat/ChatBubble';
import SuggestionChip from '../../components/AI/SuggestionChip';

const LegalChatbot = () => {
  const navigation = useNavigation();
  const { user } = useAuth();
  
  const [messages, setMessages] = useState([]);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [error, setError] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  
  const flatListRef = useRef(null);
  
  useEffect(() => {
    // إعداد عنوان الصفحة
    navigation.setOptions({
      title: 'المساعد القانوني الذكي',
    });
    
    // تحميل الرسائل السابقة
    loadPreviousMessages();
    
    // إضافة رسالة ترحيبية إذا لم تكن هناك رسائل سابقة
    setTimeout(() => {
      setInitialLoading(false);
      
      if (messages.length === 0) {
        const welcomeMessage = {
          id: 'welcome',
          text: 'مرحباً بك في المساعد القانوني الذكي! يمكنني مساعدتك في الإجابة على استفساراتك القانونية العامة. ما هو سؤالك القانوني؟',
          sender: 'bot',
          timestamp: new Date(),
          suggestions: [
            'ما هي حقوقي كموظف؟',
            'كيف أستطيع رفع دعوى قضائية؟',
            'ما هي إجراءات الطلاق في السعودية؟',
            'كيف أسجل علامة تجارية؟'
          ]
        };
        
        setMessages([welcomeMessage]);
        setSuggestions(welcomeMessage.suggestions);
      }
    }, 1000);
  }, []);
  
  const loadPreviousMessages = async () => {
    try {
      const savedMessages = await AsyncStorage.getItem('legal_chatbot_messages');
      
      if (savedMessages) {
        const parsedMessages = JSON.parse(savedMessages);
        setMessages(parsedMessages);
        
        // استخراج الاقتراحات من آخر رسالة من الروبوت
        const lastBotMessage = [...parsedMessages].reverse().find(msg => msg.sender === 'bot');
        if (lastBotMessage && lastBotMessage.suggestions) {
          setSuggestions(lastBotMessage.suggestions);
        }
      }
    } catch (error) {
      console.error('خطأ في تحميل الرسائل السابقة:', error);
    }
  };
  
  const saveMessages = async (updatedMessages) => {
    try {
      await AsyncStorage.setItem('legal_chatbot_messages', JSON.stringify(updatedMessages));
    } catch (error) {
      console.error('خطأ في حفظ الرسائل:', error);
    }
  };
  
  const handleSendMessage = async () => {
    if (!message.trim() || loading) {
      return;
    }
    
    const userMessage = {
      id: `user-${Date.now()}`,
      text: message.trim(),
      sender: 'user',
      timestamp: new Date()
    };
    
    // إضافة رسالة المستخدم إلى القائمة
    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    saveMessages(updatedMessages);
    
    // مسح حقل الرسالة
    setMessage('');
    
    // التمرير إلى أسفل القائمة
    if (flatListRef.current) {
      setTimeout(() => {
        flatListRef.current.scrollToEnd({ animated: true });
      }, 100);
    }
    
    // إرسال الرسالة إلى الخادم
    try {
      setLoading(true);
      setError('');
      
      const token = await AsyncStorage.getItem('token');
      
      const response = await axios.post(
        `${API_URL}/api/ai/legal-chatbot`,
        {
          message: message.trim(),
          conversation_history: messages.map(msg => ({
            role: msg.sender === 'user' ? 'user' : 'assistant',
            content: msg.text
          }))
        },
        {
          headers: {
            Authorization: token ? `Bearer ${token}` : undefined
          }
        }
      );
      
      if (response.data.success) {
        const botResponse = {
          id: `bot-${Date.now()}`,
          text: response.data.data.response,
          sender: 'bot',
          timestamp: new Date(),
          references: response.data.data.references || [],
          suggestions: response.data.data.suggestions || []
        };
        
        // إضافة رد الروبوت إلى القائمة
        const newMessages = [...updatedMessages, botResponse];
        setMessages(newMessages);
        saveMessages(newMessages);
        
        // تحديث الاقتراحات
        setSuggestions(botResponse.suggestions);
        
        // التمرير إلى أسفل القائمة
        if (flatListRef.current) {
          setTimeout(() => {
            flatListRef.current.scrollToEnd({ animated: true });
          }, 100);
        }
      } else {
        setError(response.data.message || 'حدث خطأ أثناء معالجة رسالتك');
      }
    } catch (error) {
      console.error('خطأ في إرسال الرسالة:', error);
      setError('حدث خطأ أثناء الاتصال بالمساعد القانوني. يرجى المحاولة مرة أخرى.');
    } finally {
      setLoading(false);
    }
  };
  
  const handleSuggestionPress = (suggestion) => {
    setMessage(suggestion);
  };
  
  const handleClearConversation = () => {
    // عرض تأكيد قبل المسح
    Alert.alert(
      'مسح المحادثة',
      'هل أنت متأكد من رغبتك في مسح جميع الرسائل؟',
      [
        {
          text: 'إلغاء',
          style: 'cancel'
        },
        {
          text: 'مسح',
          style: 'destructive',
          onPress: () => {
            // مسح جميع الرسائل
            setMessages([]);
            saveMessages([]);
            
            // إضافة رسالة ترحيبية جديدة
            setTimeout(() => {
              const welcomeMessage = {
                id: 'welcome',
                text: 'مرحباً بك في المساعد القانوني الذكي! يمكنني مساعدتك في الإجابة على استفساراتك القانونية العامة. ما هو سؤالك القانوني؟',
                sender: 'bot',
                timestamp: new Date(),
                suggestions: [
                  'ما هي حقوقي كموظف؟',
                  'كيف أستطيع رفع دعوى قضائية؟',
                  'ما هي إجراءات الطلاق في السعودية؟',
                  'كيف أسجل علامة تجارية؟'
                ]
              };
              
              setMessages([welcomeMessage]);
              setSuggestions(welcomeMessage.suggestions);
              saveMessages([welcomeMessage]);
            }, 500);
          }
        }
      ]
    );
  };
  
  if (initialLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#1976d2" />
        <Text style={styles.loadingText}>جاري تحميل المساعد القانوني...</Text>
      </View>
    );
  }
  
  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
    >
      {error ? (
        <View style={styles.errorContainer}>
          <Icon name="error-outline" size={20} color="#f44336" />
          <Text style={styles.errorText}>{error}</Text>
        </View>
      ) : null}
      
      <FlatList
        ref={flatListRef}
        data={messages}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <ChatBubble
            message={item}
            isUser={item.sender === 'user'}
          />
        )}
        contentContainerStyle={styles.messagesContainer}
        onContentSizeChange={() => flatListRef.current.scrollToEnd({ animated: true })}
        onLayout={() => flatListRef.current.scrollToEnd({ animated: true })}
      />
      
      {suggestions.length > 0 && (
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.suggestionsContainer}
        >
          {suggestions.map((suggestion, index) => (
            <SuggestionChip
              key={`suggestion-${index}`}
              text={suggestion}
              onPress={() => handleSuggestionPress(suggestion)}
            />
          ))}
        </ScrollView>
      )}
      
      <View style={styles.disclaimerContainer}>
        <Icon name="info-outline" size={16} color="#666" />
        <Text style={styles.disclaimerText}>
          هذا المساعد يقدم معلومات قانونية عامة وليس بديلاً عن استشارة محامٍ مؤهل.
        </Text>
      </View>
      
      <View style={styles.inputContainer}>
        <TouchableOpacity
          style={styles.clearButton}
          onPress={handleClearConversation}
        >
          <Icon name="delete-outline" size={24} color="#f44336" />
        </TouchableOpacity>
        
        <TextInput
          style={styles.input}
          placeholder="اكتب سؤالك القانوني هنا..."
          placeholderTextColor="#999"
          value={message}
          onChangeText={setMessage}
          multiline
        />
        
        <TouchableOpacity
          style={[
            styles.sendButton,
            (!message.trim() || loading) ? styles.sendButtonDisabled : {}
          ]}
          onPress={handleSendMessage}
          disabled={!message.trim() || loading}
        >
          {loading ? (
            <ActivityIndicator size="small" color="#fff" />
          ) : (
            <Icon name="send" size={24} color="#fff" />
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  messagesContainer: {
    padding: 10,
    paddingBottom: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 10,
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
  },
  clearButton: {
    padding: 5,
    marginRight: 5,
  },
  input: {
    flex: 1,
    backgroundColor: '#f0f0f0',
    borderRadius: 20,
    paddingHorizontal: 15,
    paddingVertical: 10,
    maxHeight: 100,
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#333',
    textAlign: 'right',
  },
  sendButton: {
    backgroundColor: '#1976d2',
    borderRadius: 25,
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 10,
  },
  sendButtonDisabled: {
    backgroundColor: '#b0bec5',
  },
  suggestionsContainer: {
    flexDirection: 'row',
    padding: 10,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
  },
  disclaimerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    padding: 8,
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
  },
  disclaimerText: {
    fontFamily: 'Cairo-Regular',
    fontSize: 12,
    color: '#666',
    marginRight: 5,
    flex: 1,
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffebee',
    padding: 10,
    margin: 10,
    borderRadius: 5,
  },
  errorText: {
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#f44336',
    marginRight: 10,
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontFamily: 'Cairo-Regular',
    fontSize: 16,
    color: '#666',
    marginTop: 10,
  },
});

export default LegalChatbot;
