// مولد المستندات القانونية - معدل للقوانين العراقية
import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TextInput, 
  TouchableOpacity, 
  ActivityIndicator,
  Alert,
  Platform
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import DocumentPicker from 'react-native-document-picker';
import RNFS from 'react-native-fs';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { API_URL } from '../../config';
import { useAuth } from '../../contexts/AuthContext';
import DropdownSelect from '../../components/UI/DropdownSelect';
import PrimaryButton from '../../components/UI/PrimaryButton';
import SecondaryButton from '../../components/UI/SecondaryButton';

const DocumentGenerator = () => {
  const navigation = useNavigation();
  const { user } = useAuth();
  
  const [documentType, setDocumentType] = useState('');
  const [documentFields, setDocumentFields] = useState({});
  const [documentTemplate, setDocumentTemplate] = useState(null);
  const [generatedDocument, setGeneratedDocument] = useState(null);
  const [uploadedDocument, setUploadedDocument] = useState(null);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState('');
  
  // قائمة أنواع المستندات القانونية في العراق
  const documentTypes = [
    { label: 'عقد عمل', value: 'employment_contract' },
    { label: 'عقد إيجار سكني', value: 'residential_lease' },
    { label: 'عقد إيجار تجاري', value: 'commercial_lease' },
    { label: 'عقد بيع عقار', value: 'real_estate_sale' },
    { label: 'عقد بيع سيارة', value: 'vehicle_sale' },
    { label: 'وكالة عامة', value: 'general_power_of_attorney' },
    { label: 'وكالة خاصة', value: 'special_power_of_attorney' },
    { label: 'إنذار قانوني', value: 'legal_notice' },
    { label: 'دعوى قضائية', value: 'lawsuit' },
    { label: 'اتفاقية تسوية', value: 'settlement_agreement' },
    { label: 'عقد تأسيس شركة', value: 'company_establishment' },
    { label: 'عقد شراكة', value: 'partnership_agreement' },
    { label: 'وصية', value: 'will' },
    { label: 'إقرار دين', value: 'debt_acknowledgment' },
    { label: 'شكوى جزائية', value: 'criminal_complaint' }
  ];
  
  useEffect(() => {
    // إعداد عنوان الصفحة
    navigation.setOptions({
      title: 'مولد المستندات القانونية',
    });
  }, []);
  
  useEffect(() => {
    if (documentType) {
      fetchDocumentTemplate();
    } else {
      setDocumentTemplate(null);
      setDocumentFields({});
    }
  }, [documentType]);
  
  const fetchDocumentTemplate = async () => {
    try {
      setLoading(true);
      setError('');
      
      const token = await AsyncStorage.getItem('token');
      
      const response = await axios.get(
        `${API_URL}/api/documents/template/${documentType}`,
        {
          headers: {
            Authorization: token ? `Bearer ${token}` : undefined
          }
        }
      );
      
      if (response.data.success) {
        setDocumentTemplate(response.data.data);
        
        // إنشاء كائن فارغ للحقول
        const fields = {};
        response.data.data.fields.forEach(field => {
          fields[field.name] = '';
        });
        
        setDocumentFields(fields);
      } else {
        setError(response.data.message || 'فشل تحميل قالب المستند');
      }
    } catch (error) {
      console.error('خطأ في تحميل قالب المستند:', error);
      setError('حدث خطأ أثناء تحميل قالب المستند. يرجى المحاولة مرة أخرى.');
    } finally {
      setLoading(false);
    }
  };
  
  const handleFieldChange = (fieldName, value) => {
    setDocumentFields(prevFields => ({
      ...prevFields,
      [fieldName]: value
    }));
  };
  
  const handleGenerateDocument = async () => {
    // التحقق من إدخال جميع الحقول المطلوبة
    const requiredFields = documentTemplate.fields.filter(field => field.required);
    const missingFields = requiredFields.filter(field => !documentFields[field.name]);
    
    if (missingFields.length > 0) {
      const missingFieldNames = missingFields.map(field => field.label).join('، ');
      setError(`يرجى إدخال الحقول المطلوبة: ${missingFieldNames}`);
      return;
    }
    
    try {
      setGenerating(true);
      setError('');
      
      const token = await AsyncStorage.getItem('token');
      
      if (!token && documentTemplate.requires_auth) {
        navigation.navigate('تسجيل الدخول');
        return;
      }
      
      const response = await axios.post(
        `${API_URL}/api/documents/generate`,
        {
          document_type: documentType,
          fields: documentFields
        },
        {
          headers: {
            Authorization: token ? `Bearer ${token}` : undefined
          }
        }
      );
      
      if (response.data.success) {
        setGeneratedDocument(response.data.data);
        
        // الانتقال إلى صفحة معاينة المستند
        navigation.navigate('معاينة المستند', {
          document: response.data.data,
          documentType: documentTypes.find(type => type.value === documentType)?.label || documentType
        });
      } else {
        setError(response.data.message || 'فشل إنشاء المستند');
      }
    } catch (error) {
      console.error('خطأ في إنشاء المستند:', error);
      setError('حدث خطأ أثناء إنشاء المستند. يرجى المحاولة مرة أخرى.');
    } finally {
      setGenerating(false);
    }
  };
  
  const handleUploadDocument = async () => {
    try {
      const result = await DocumentPicker.pick({
        type: [DocumentPicker.types.pdf, DocumentPicker.types.doc, DocumentPicker.types.docx],
      });
      
      const fileUri = Platform.OS === 'ios' ? result[0].uri.replace('file://', '') : result[0].uri;
      const fileName = result[0].name;
      const fileType = result[0].type;
      
      // قراءة الملف كـ base64
      const base64Data = await RNFS.readFile(fileUri, 'base64');
      
      setUploadedDocument({
        name: fileName,
        type: fileType,
        uri: fileUri,
        base64: base64Data
      });
      
      // تحليل المستند المرفوع
      handleAnalyzeDocument(base64Data, fileType);
    } catch (error) {
      if (DocumentPicker.isCancel(error)) {
        // المستخدم ألغى العملية
      } else {
        console.error('خطأ في رفع المستند:', error);
        setError('حدث خطأ أثناء رفع المستند. يرجى المحاولة مرة أخرى.');
      }
    }
  };
  
  const handleAnalyzeDocument = async (base64Data, fileType) => {
    try {
      setAnalyzing(true);
      setError('');
      
      const token = await AsyncStorage.getItem('token');
      
      const response = await axios.post(
        `${API_URL}/api/documents/analyze`,
        {
          document: base64Data,
          document_type: fileType
        },
        {
          headers: {
            Authorization: token ? `Bearer ${token}` : undefined
          }
        }
      );
      
      if (response.data.success) {
        // تحديد نوع المستند تلقائياً
        if (response.data.data.document_type) {
          setDocumentType(response.data.data.document_type);
        }
        
        // ملء الحقول تلقائياً
        if (response.data.data.extracted_fields) {
          setDocumentFields(response.data.data.extracted_fields);
        }
        
        Alert.alert(
          'تم تحليل المستند',
          'تم تحليل المستند بنجاح وملء الحقول تلقائياً. يرجى مراجعة البيانات وتعديلها إذا لزم الأمر.',
          [{ text: 'حسناً' }]
        );
      } else {
        setError(response.data.message || 'فشل تحليل المستند');
      }
    } catch (error) {
      console.error('خطأ في تحليل المستند:', error);
      setError('حدث خطأ أثناء تحليل المستند. يرجى المحاولة مرة أخرى.');
    } finally {
      setAnalyzing(false);
    }
  };
  
  const renderDocumentFields = () => {
    if (!documentTemplate || !documentTemplate.fields) {
      return null;
    }
    
    return (
      <View style={styles.fieldsContainer}>
        {documentTemplate.fields.map((field, index) => (
          <View key={`field-${index}`} style={styles.fieldItem}>
            <Text style={styles.fieldLabel}>
              {field.label}
              {field.required && <Text style={styles.requiredMark}>*</Text>}
            </Text>
            
            {field.type === 'text' && (
              <TextInput
                style={styles.textInput}
                value={documentFields[field.name] || ''}
                onChangeText={(value) => handleFieldChange(field.name, value)}
                placeholder={field.placeholder || `أدخل ${field.label}`}
                placeholderTextColor="#999"
              />
            )}
            
            {field.type === 'textarea' && (
              <TextInput
                style={styles.textareaInput}
                value={documentFields[field.name] || ''}
                onChangeText={(value) => handleFieldChange(field.name, value)}
                multiline
                numberOfLines={4}
                textAlignVertical="top"
                placeholder={field.placeholder || `أدخل ${field.label}`}
                placeholderTextColor="#999"
              />
            )}
            
            {field.type === 'date' && (
              <TouchableOpacity
                style={styles.datePickerButton}
                onPress={() => {
                  // فتح منتقي التاريخ
                  // يمكن استخدام مكتبة مثل react-native-date-picker
                }}
              >
                <Text style={styles.datePickerButtonText}>
                  {documentFields[field.name] || field.placeholder || 'اختر التاريخ'}
                </Text>
                <Icon name="calendar-today" size={20} color="#666" />
              </TouchableOpacity>
            )}
            
            {field.type === 'select' && field.options && (
              <DropdownSelect
                label={field.placeholder || `اختر ${field.label}`}
                items={field.options.map(option => ({
                  label: option.label,
                  value: option.value
                }))}
                value={documentFields[field.name] || ''}
                onValueChange={(value) => handleFieldChange(field.name, value)}
                placeholder={field.placeholder || `اختر ${field.label}`}
              />
            )}
            
            {field.description && (
              <Text style={styles.fieldDescription}>{field.description}</Text>
            )}
          </View>
        ))}
      </View>
    );
  };
  
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      {error ? (
        <View style={styles.errorContainer}>
          <Icon name="error-outline" size={20} color="#f44336" />
          <Text style={styles.errorText}>{error}</Text>
        </View>
      ) : null}
      
      <View style={styles.uploadContainer}>
        <Text style={styles.sectionTitle}>تحميل مستند موجود</Text>
        <Text style={styles.sectionDescription}>
          يمكنك تحميل مستند موجود لتحليله وتعديله، أو إنشاء مستند جديد من القوالب المتاحة.
        </Text>
        
        <SecondaryButton
          title={analyzing ? 'جاري تحليل المستند...' : 'تحميل مستند'}
          onPress={handleUploadDocument}
          disabled={analyzing}
          loading={analyzing}
          icon="upload-file"
        />
        
        {uploadedDocument && (
          <View style={styles.uploadedFileContainer}>
            <Icon name="description" size={24} color="#1976d2" />
            <Text style={styles.uploadedFileName}>{uploadedDocument.name}</Text>
          </View>
        )}
      </View>
      
      <View style={styles.templateContainer}>
        <Text style={styles.sectionTitle}>إنشاء مستند جديد</Text>
        
        <View style={styles.documentTypeContainer}>
          <Text style={styles.fieldLabel}>نوع المستند</Text>
          <DropdownSelect
            label="اختر نوع المستند"
            items={documentTypes}
            value={documentType}
            onValueChange={setDocumentType}
            placeholder="اختر نوع المستند"
          />
        </View>
        
        {loading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="small" color="#1976d2" />
            <Text style={styles.loadingText}>جاري تحميل قالب المستند...</Text>
          </View>
        ) : documentTemplate ? (
          <>
            <View style={styles.templateInfoContainer}>
              <Text style={styles.templateTitle}>{documentTemplate.title}</Text>
              <Text style={styles.templateDescription}>{documentTemplate.description}</Text>
            </View>
            
            {renderDocumentFields()}
            
            <View style={styles.actionsContainer}>
              <PrimaryButton
                title={generating ? 'جاري إنشاء المستند...' : 'إنشاء المستند'}
                onPress={handleGenerateDocument}
                disabled={generating}
                loading={generating}
              />
            </View>
          </>
        ) : documentType ? (
          <View style={styles.emptyStateContainer}>
            <Icon name="search-off" size={40} color="#b0bec5" />
            <Text style={styles.emptyStateText}>
              لم يتم العثور على قالب لهذا النوع من المستندات
            </Text>
          </View>
        ) : null}
      </View>
      
      <View style={styles.disclaimerContainer}>
        <Icon name="info-outline" size={16} color="#666" />
        <Text style={styles.disclaimerText}>
          المستندات المنشأة هي لأغراض إرشادية فقط وقد تحتاج إلى مراجعة من قبل محامٍ مختص قبل استخدامها. المستندات متوافقة مع القوانين العراقية النافذة.
        </Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  contentContainer: {
    padding: 15,
    paddingBottom: 30,
  },
  uploadContainer: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 20,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  templateContainer: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 20,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  sectionTitle: {
    fontFamily: 'Cairo-Bold',
    fontSize: 18,
    color: '#333',
    marginBottom: 10,
    textAlign: 'right',
  },
  sectionDescription: {
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#666',
    marginBottom: 15,
    textAlign: 'right',
  },
  uploadedFileContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    backgroundColor: '#e3f2fd',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
  },
  uploadedFileName: {
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#1976d2',
    marginRight: 10,
  },
  documentTypeContainer: {
    marginBottom: 15,
  },
  templateInfoContainer: {
    marginBottom: 15,
    padding: 10,
    backgroundColor: '#f5f5f5',
    borderRadius: 5,
  },
  templateTitle: {
    fontFamily: 'Cairo-Bold',
    fontSize: 16,
    color: '#333',
    marginBottom: 5,
    textAlign: 'right',
  },
  templateDescription: {
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#666',
    textAlign: 'right',
  },
  fieldsContainer: {
    marginBottom: 15,
  },
  fieldItem: {
    marginBottom: 15,
  },
  fieldLabel: {
    fontFamily: 'Cairo-Bold',
    fontSize: 14,
    color: '#333',
    marginBottom: 5,
    textAlign: 'right',
  },
  requiredMark: {
    color: '#f44336',
    marginRight: 3,
  },
  textInput: {
    backgroundColor: '#f0f0f0',
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ddd',
    padding: 10,
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#333',
    textAlign: 'right',
  },
  textareaInput: {
    backgroundColor: '#f0f0f0',
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ddd',
    padding: 10,
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#333',
    textAlign: 'right',
    minHeight: 100,
  },
  datePickerButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#f0f0f0',
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ddd',
    padding: 10,
  },
  datePickerButtonText: {
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#333',
  },
  fieldDescription: {
    fontFamily: 'Cairo-Regular',
    fontSize: 12,
    color: '#999',
    marginTop: 3,
    textAlign: 'right',
  },
  actionsContainer: {
    marginTop: 10,
  },
  disclaimerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
  },
  disclaimerText: {
    fontFamily: 'Cairo-Regular',
    fontSize: 12,
    color: '#666',
    marginRight: 5,
    flex: 1,
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffebee',
    padding: 10,
    marginBottom: 15,
    borderRadius: 5,
  },
  errorText: {
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#f44336',
    marginRight: 10,
    flex: 1,
  },
  loadingContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  loadingText: {
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#666',
    marginTop: 10,
  },
  emptyStateContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  emptyStateText: {
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#666',
    marginTop: 10,
    textAlign: 'center',
  },
});

export default DocumentGenerator;
