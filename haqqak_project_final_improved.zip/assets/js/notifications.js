/**
 * نظام الإشعارات لمنصة حقك تعرف العراق
 * يوفر وظائف لإدارة الإشعارات للمحامين والعملاء
 */

// تهيئة نظام الإشعارات
document.addEventListener('DOMContentLoaded', function() {
    // تحقق من وجود إشعارات جديدة عند تحميل الصفحة
    checkForNewNotifications();
    
    // تحقق من وجود إشعارات جديدة كل دقيقة
    setInterval(checkForNewNotifications, 60000);
    
    // تهيئة عداد الإشعارات في الشريط العلوي
    initNotificationCounter();
    
    // تهيئة قائمة الإشعارات المنسدلة
    initNotificationDropdown();
});

/**
 * التحقق من وجود إشعارات جديدة
 */
function checkForNewNotifications() {
    // في التطبيق الحقيقي، سيتم استدعاء API للتحقق من وجود إشعارات جديدة
    // هنا نقوم بمحاكاة ذلك لأغراض العرض
    
    // محاكاة استدعاء API
    simulateAPICall()
        .then(response => {
            if (response.success) {
                updateNotificationCounter(response.data.unreadCount);
                updateNotificationList(response.data.notifications);
                
                // إذا كان هناك إشعارات جديدة، عرض إشعار للمستخدم
                if (response.data.unreadCount > 0) {
                    showNotificationAlert(response.data.unreadCount);
                }
            }
        })
        .catch(error => {
            console.error('خطأ في التحقق من الإشعارات:', error);
        });
}

/**
 * محاكاة استدعاء API للحصول على الإشعارات
 * في التطبيق الحقيقي، سيتم استبدال هذا بطلب API فعلي
 */
function simulateAPICall() {
    return new Promise((resolve) => {
        // محاكاة تأخير الشبكة
        setTimeout(() => {
            // بيانات محاكاة للإشعارات
            const mockData = {
                success: true,
                data: {
                    unreadCount: Math.floor(Math.random() * 5), // عدد عشوائي من 0 إلى 4
                    notifications: [
                        {
                            id: 1,
                            type: 'new_consultation',
                            title: 'استشارة جديدة',
                            message: 'تم استلام استشارة جديدة حول قانون العمل',
                            time: 'منذ 5 دقائق',
                            isRead: false,
                            link: 'lawyer_dashboard.html#new-consultations'
                        },
                        {
                            id: 2,
                            type: 'urgent_consultation',
                            title: 'استشارة عاجلة',
                            message: 'استشارة عاجلة تتطلب الرد خلال 30 دقيقة',
                            time: 'منذ 15 دقيقة',
                            isRead: false,
                            link: 'lawyer_dashboard.html#new-consultations'
                        },
                        {
                            id: 3,
                            type: 'consultation_reply',
                            title: 'رد على استشارتك',
                            message: 'تم الرد على استشارتك حول عقد الإيجار',
                            time: 'منذ ساعة',
                            isRead: true,
                            link: 'client_consultations.html'
                        },
                        {
                            id: 4,
                            type: 'meeting_scheduled',
                            title: 'موعد مقابلة جديد',
                            message: 'تم تحديد موعد مقابلة غداً الساعة 2 مساءً',
                            time: 'منذ ساعتين',
                            isRead: true,
                            link: 'lawyer_dashboard.html#meetings'
                        },
                        {
                            id: 5,
                            type: 'payment_received',
                            title: 'دفعة جديدة',
                            message: 'تم استلام دفعة جديدة بقيمة 15,000 دينار عراقي',
                            time: 'منذ 3 ساعات',
                            isRead: true,
                            link: 'lawyer_dashboard.html#payments'
                        }
                    ]
                }
            };
            
            resolve(mockData);
        }, 500);
    });
}

/**
 * تحديث عداد الإشعارات في الشريط العلوي
 */
function updateNotificationCounter(count) {
    const notificationBadge = document.querySelector('.notification-badge');
    if (notificationBadge) {
        if (count > 0) {
            notificationBadge.textContent = count;
            notificationBadge.classList.remove('d-none');
        } else {
            notificationBadge.classList.add('d-none');
        }
    }
}

/**
 * تحديث قائمة الإشعارات في القائمة المنسدلة
 */
function updateNotificationList(notifications) {
    const notificationDropdown = document.querySelector('.notification-dropdown-menu');
    if (!notificationDropdown) return;
    
    // حذف الإشعارات الحالية (باستثناء العنوان والرابط في النهاية)
    const items = notificationDropdown.querySelectorAll('.notification-item');
    items.forEach(item => item.remove());
    
    // إضافة الإشعارات الجديدة
    const headerItem = notificationDropdown.querySelector('.dropdown-header');
    
    notifications.forEach(notification => {
        const item = document.createElement('li');
        item.innerHTML = `
            <a class="dropdown-item notification-item ${notification.isRead ? '' : 'unread'}" href="${notification.link}">
                <div class="d-flex align-items-start">
                    <div>
                        <i class="fas ${getNotificationIcon(notification.type)}"></i>
                    </div>
                    <div>
                        <div class="notification-title">${notification.title}</div>
                        <div class="notification-text">${notification.message}</div>
                        <div class="notification-time">${notification.time}</div>
                    </div>
                </div>
            </a>
        `;
        
        // إدراج بعد العنوان
        if (headerItem) {
            headerItem.after(item);
        } else {
            notificationDropdown.prepend(item);
        }
    });
}

/**
 * الحصول على أيقونة مناسبة لنوع الإشعار
 */
function getNotificationIcon(type) {
    switch (type) {
        case 'new_consultation':
            return 'fa-file-alt';
        case 'urgent_consultation':
            return 'fa-exclamation-circle';
        case 'consultation_reply':
            return 'fa-comment-dots';
        case 'meeting_scheduled':
            return 'fa-calendar-check';
        case 'payment_received':
            return 'fa-money-bill-wave';
        default:
            return 'fa-bell';
    }
}

/**
 * عرض تنبيه للمستخدم بوجود إشعارات جديدة
 */
function showNotificationAlert(count) {
    // التحقق من دعم إشعارات المتصفح
    if (!("Notification" in window)) {
        console.log("هذا المتصفح لا يدعم إشعارات سطح المكتب");
        return;
    }
    
    // التحقق من إذن الإشعارات
    if (Notification.permission === "granted") {
        createNotification(count);
    } else if (Notification.permission !== "denied") {
        Notification.requestPermission().then(permission => {
            if (permission === "granted") {
                createNotification(count);
            }
        });
    }
}

/**
 * إنشاء إشعار سطح المكتب
 */
function createNotification(count) {
    const title = `لديك ${count} إشعارات جديدة`;
    const options = {
        body: 'انقر لعرض الإشعارات الجديدة',
        icon: 'images/logo.png'
    };
    
    const notification = new Notification(title, options);
    
    notification.onclick = function() {
        window.focus();
        this.close();
    };
}

/**
 * تهيئة عداد الإشعارات في الشريط العلوي
 */
function initNotificationCounter() {
    // التحقق من وجود أيقونة الإشعارات
    const notificationIcon = document.querySelector('.notification-dropdown');
    if (!notificationIcon) {
        // إنشاء أيقونة الإشعارات إذا لم تكن موجودة
        createNotificationIcon();
    }
}

/**
 * إنشاء أيقونة الإشعارات في الشريط العلوي
 */
function createNotificationIcon() {
    // التحقق من وجود قائمة العناصر في الشريط العلوي
    const navbarNav = document.querySelector('#navbarNav .navbar-nav');
    if (!navbarNav) return;
    
    // إنشاء عنصر قائمة جديد
    const listItem = document.createElement('li');
    listItem.className = 'nav-item dropdown';
    
    // إنشاء رابط القائمة المنسدلة
    listItem.innerHTML = `
        <a class="nav-link dropdown-toggle position-relative notification-dropdown" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-bell"></i>
            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger notification-badge d-none">
                0
            </span>
        </a>
        <ul class="dropdown-menu dropdown-menu-end notification-dropdown-menu" aria-labelledby="notificationsDropdown">
            <li><h6 class="dropdown-header">الإشعارات</h6></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-center" href="#">عرض جميع الإشعارات</a></li>
        </ul>
    `;
    
    // إضافة العنصر إلى القائمة
    navbarNav.prepend(listItem);
}

/**
 * تهيئة قائمة الإشعارات المنسدلة
 */
function initNotificationDropdown() {
    // سيتم تنفيذ هذا في التطبيق الحقيقي
    // هنا نكتفي بالمحاكاة
}

/**
 * تحديث حالة قراءة الإشعار
 */
function markNotificationAsRead(notificationId) {
    // في التطبيق الحقيقي، سيتم استدعاء API لتحديث حالة الإشعار
    console.log(`تم تحديث حالة الإشعار ${notificationId} إلى مقروء`);
    
    // تحديث واجهة المستخدم
    const notificationItem = document.querySelector(`.notification-item[data-id="${notificationId}"]`);
    if (notificationItem) {
        notificationItem.classList.remove('unread');
    }
    
    // تحديث عداد الإشعارات غير المقروءة
    updateUnreadNotificationsCount();
}

/**
 * تحديث عدد الإشعارات غير المقروءة
 */
function updateUnreadNotificationsCount() {
    // في التطبيق الحقيقي، سيتم استدعاء API للحصول على العدد الدقيق
    // هنا نقوم بحساب العدد من واجهة المستخدم
    const unreadItems = document.querySelectorAll('.notification-item.unread');
    updateNotificationCounter(unreadItems.length);
}
