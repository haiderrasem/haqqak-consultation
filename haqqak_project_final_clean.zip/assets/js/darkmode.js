/**
 * Dark Mode functionality for Haqqak Ta3ref Iraq
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize dark mode
    initDarkMode();
});

/**
 * Initialize dark mode functionality
 */
function initDarkMode() {
    const darkModeToggle = document.getElementById('darkModeToggle');
    const darkModeToggleMobile = document.getElementById('darkModeToggleMobile');
    
    // Check for stored preference
    const darkModeEnabled = localStorage.getItem('darkModeEnabled') === 'true';
    
    // Apply initial theme
    if (darkModeEnabled) {
        document.documentElement.setAttribute('data-theme', 'dark');
        updateDarkModeIcons(true);
    }
    
    // Add event listeners
    if (darkModeToggle) {
        darkModeToggle.addEventListener('click', toggleDarkMode);
    }
    
    if (darkModeToggleMobile) {
        darkModeToggleMobile.addEventListener('click', toggleDarkMode);
    }
}

/**
 * Toggle dark mode
 */
function toggleDarkMode() {
    const isDarkMode = document.documentElement.getAttribute('data-theme') === 'dark';
    
    if (isDarkMode) {
        document.documentElement.removeAttribute('data-theme');
        localStorage.setItem('darkModeEnabled', 'false');
    } else {
        document.documentElement.setAttribute('data-theme', 'dark');
        localStorage.setItem('darkModeEnabled', 'true');
    }
    
    updateDarkModeIcons(!isDarkMode);
}

/**
 * Update dark mode icons
 */
function updateDarkModeIcons(isDarkMode) {
    const darkModeToggle = document.getElementById('darkModeToggle');
    const darkModeToggleMobile = document.getElementById('darkModeToggleMobile');
    
    if (darkModeToggle) {
        const icon = darkModeToggle.querySelector('i');
        updateIcon(icon, isDarkMode);
    }
    
    if (darkModeToggleMobile) {
        const icon = darkModeToggleMobile.querySelector('i');
        updateIcon(icon, isDarkMode);
    }
    
    function updateIcon(icon, isDarkMode) {
        if (isDarkMode) {
            icon.classList.remove('fa-moon');
            icon.classList.add('fa-sun');
        } else {
            icon.classList.remove('fa-sun');
            icon.classList.add('fa-moon');
        }
    }
}

/**
 * Check system preference for dark mode
 */
function checkSystemDarkModePreference() {
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        document.documentElement.setAttribute('data-theme', 'dark');
        localStorage.setItem('darkModeEnabled', 'true');
        updateDarkModeIcons(true);
    }
}

// Check system preference if no stored preference
if (localStorage.getItem('darkModeEnabled') === null) {
    checkSystemDarkModePreference();
}

// Listen for system preference changes
if (window.matchMedia) {
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
        if (localStorage.getItem('darkModeEnabled') === null) {
            if (e.matches) {
                document.documentElement.setAttribute('data-theme', 'dark');
                updateDarkModeIcons(true);
            } else {
                document.documentElement.removeAttribute('data-theme');
                updateDarkModeIcons(false);
            }
        }
    });
}
