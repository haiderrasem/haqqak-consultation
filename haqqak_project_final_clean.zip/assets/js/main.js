/**
 * Main JavaScript for Haqqak Ta3ref Iraq
 * Includes functionality for form validation, animations, and Iraq-specific features
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize animations
    initAnimations();
    
    // Initialize form validation
    initFormValidation();
    
    // Initialize Iraq-specific phone validation
    initIraqiPhoneValidation();
    
    // Initialize password strength meter
    initPasswordStrength();
    
    // Initialize font size controls
    initFontSizeControls();
    
    // Initialize high contrast toggle
    initHighContrastToggle();
    
    // Initialize password visibility toggles
    initPasswordToggles();
    
    // Initialize response time and payment options
    initResponseTimeOptions();
});

/**
 * Initialize scroll animations
 */
function initAnimations() {
    const animatedElements = document.querySelectorAll('.animate-on-scroll');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('show');
            }
        });
    }, {
        threshold: 0.1
    });
    
    animatedElements.forEach(element => {
        observer.observe(element);
    });
}

/**
 * Initialize form validation
 */
function initFormValidation() {
    const forms = document.querySelectorAll('.needs-validation');
    
    Array.from(forms).forEach(form => {
        // Add conditional validation for lawyer registration form
        if (form.id === 'lawyerRegisterForm') {
            initLawyerFormConditionalValidation(form);
        }
        
        form.addEventListener('submit', event => {
            // Run conditional validation for lawyer registration form
            if (form.id === 'lawyerRegisterForm') {
                const barIdImage = form.querySelector('#barIdImage');
                const licenseImage = form.querySelector('#licenseImage');
                
                // Check if at least one of the documents is provided
                if (barIdImage && licenseImage) {
                    if (!barIdImage.files.length && !licenseImage.files.length) {
                        event.preventDefault();
                        event.stopPropagation();
                        
                        // Set custom validation message
                        licenseImage.setCustomValidity('يجب إرفاق صورة هوية نقابة المحامين العراقيين أو وثيقة التخرج على الأقل');
                    }
                }
            }
            
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            form.classList.add('was-validated');
        }, false);
        
        // Custom validation messages
        const inputs = form.querySelectorAll('[data-error-message]');
        inputs.forEach(input => {
            input.addEventListener('invalid', () => {
                input.setCustomValidity(input.getAttribute('data-error-message'));
            });
            
            input.addEventListener('input', () => {
                input.setCustomValidity('');
            });
        });
    });
}

/**
 * Initialize conditional validation for lawyer registration form
 */
function initLawyerFormConditionalValidation(form) {
    const barIdImage = form.querySelector('#barIdImage');
    const licenseImage = form.querySelector('#licenseImage');
    
    if (barIdImage && licenseImage) {
        // Update validation on file selection
        barIdImage.addEventListener('change', function() {
            updateDocumentValidation(barIdImage, licenseImage);
        });
        
        licenseImage.addEventListener('change', function() {
            updateDocumentValidation(barIdImage, licenseImage);
        });
    }
}

/**
 * Update document validation based on file selection
 */
function updateDocumentValidation(barIdImage, licenseImage) {
    // If bar ID is provided, make license optional
    if (barIdImage.files.length > 0) {
        licenseImage.removeAttribute('required');
    } 
    // If bar ID is not provided, make license required
    else {
        licenseImage.setAttribute('required', '');
    }
    
    // Reset custom validity
    barIdImage.setCustomValidity('');
    licenseImage.setCustomValidity('');
}

/**
 * Initialize Iraq-specific phone validation
 */
function initIraqiPhoneValidation() {
    const phoneInputs = document.querySelectorAll('[data-validate-iraqi-phone="true"]');
    
    phoneInputs.forEach(input => {
        input.addEventListener('input', function() {
            validateIraqiPhone(this);
        });
        
        input.addEventListener('blur', function() {
            validateIraqiPhone(this);
        });
    });
    
    function validateIraqiPhone(input) {
        const value = input.value.trim();
        const iraqiPhoneRegex = /^07[0-9]{8}$/;
        
        if (value === '') {
            input.setCustomValidity(input.getAttribute('data-error-message') || 'يرجى إدخال رقم هاتف');
        } else if (!iraqiPhoneRegex.test(value)) {
            input.setCustomValidity('يرجى إدخال رقم هاتف عراقي صحيح (يبدأ بـ 07)');
        } else {
            input.setCustomValidity('');
        }
    }
}

/**
 * Initialize password strength meter
 */
function initPasswordStrength() {
    const passwordInputs = document.querySelectorAll('[data-password-strength="true"]');
    
    passwordInputs.forEach(input => {
        // Create strength meter elements
        const meterContainer = document.createElement('div');
        meterContainer.className = 'mt-2';
        
        const meter = document.createElement('div');
        meter.className = 'password-strength-meter';
        meter.style.width = '0%';
        meter.style.height = '5px';
        meter.style.backgroundColor = '#e9ecef';
        
        const text = document.createElement('div');
        text.className = 'password-strength-text small';
        
        // Insert after input
        input.parentNode.insertBefore(meterContainer, input.nextSibling);
        meterContainer.appendChild(meter);
        meterContainer.appendChild(text);
        
        // Add event listener
        input.addEventListener('input', function() {
            const strength = calculatePasswordStrength(this.value);
            updatePasswordStrengthMeter(meter, text, strength);
        });
    });
    
    function calculatePasswordStrength(password) {
        let strength = 0;
        
        if (password.length >= 8) strength += 25;
        if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength += 25;
        if (password.match(/[0-9]/)) strength += 25;
        if (password.match(/[^a-zA-Z0-9]/)) strength += 25;
        
        return strength;
    }
    
    function updatePasswordStrengthMeter(meter, text, strength) {
        meter.style.width = strength + '%';
        
        if (strength < 25) {
            meter.style.backgroundColor = '#dc3545';
            text.textContent = 'ضعيفة جداً';
            text.style.color = '#dc3545';
        } else if (strength < 50) {
            meter.style.backgroundColor = '#ffc107';
            text.textContent = 'ضعيفة';
            text.style.color = '#ffc107';
        } else if (strength < 75) {
            meter.style.backgroundColor = '#17a2b8';
            text.textContent = 'متوسطة';
            text.style.color = '#17a2b8';
        } else {
            meter.style.backgroundColor = '#28a745';
            text.textContent = 'قوية';
            text.style.color = '#28a745';
        }
    }
}

/**
 * Initialize font size controls
 */
function initFontSizeControls() {
    // Mobile button
    const fontSizeIncreaseMobile = document.getElementById('fontSizeIncreaseMobile');
    if (fontSizeIncreaseMobile) {
        fontSizeIncreaseMobile.addEventListener('click', function() {
            changeFontSize('increase');
        });
    }
    
    // Check for stored font size preference
    const storedFontSize = localStorage.getItem('fontSizePreference');
    if (storedFontSize) {
        document.body.classList.add(storedFontSize);
    }
}

/**
 * Change font size
 */
function changeFontSize(action) {
    if (action === 'increase') {
        if (document.body.classList.contains('font-size-larger')) {
            // Already at maximum size
            return;
        } else if (document.body.classList.contains('font-size-large')) {
            document.body.classList.remove('font-size-large');
            document.body.classList.add('font-size-larger');
            localStorage.setItem('fontSizePreference', 'font-size-larger');
        } else {
            document.body.classList.add('font-size-large');
            localStorage.setItem('fontSizePreference', 'font-size-large');
        }
    } else if (action === 'decrease') {
        if (document.body.classList.contains('font-size-larger')) {
            document.body.classList.remove('font-size-larger');
            document.body.classList.add('font-size-large');
            localStorage.setItem('fontSizePreference', 'font-size-large');
        } else if (document.body.classList.contains('font-size-large')) {
            document.body.classList.remove('font-size-large');
            localStorage.removeItem('fontSizePreference');
        }
    }
}

/**
 * Initialize high contrast toggle
 */
function initHighContrastToggle() {
    const highContrastToggle = document.getElementById('highContrastToggle');
    if (highContrastToggle) {
        // Check for stored preference
        const highContrastEnabled = localStorage.getItem('highContrastEnabled') === 'true';
        if (highContrastEnabled) {
            document.documentElement.setAttribute('data-high-contrast', 'true');
        }
        
        highContrastToggle.addEventListener('click', function() {
            const isEnabled = document.documentElement.getAttribute('data-high-contrast') === 'true';
            
            if (isEnabled) {
                document.documentElement.removeAttribute('data-high-contrast');
                localStorage.setItem('highContrastEnabled', 'false');
            } else {
                document.documentElement.setAttribute('data-high-contrast', 'true');
                localStorage.setItem('highContrastEnabled', 'true');
            }
        });
    }
}

/**
 * Initialize password visibility toggles
 */
function initPasswordToggles() {
    const toggleButtons = document.querySelectorAll('[id^="toggle"]');
    
    toggleButtons.forEach(button => {
        button.addEventListener('click', function() {
            const targetId = this.id.replace('toggle', '');
            let targetInput;
            
            if (targetId === 'Password') {
                targetInput = document.getElementById('loginPassword');
            } else if (targetId === 'RegisterPassword') {
                targetInput = document.getElementById('registerPassword');
            } else if (targetId === 'ConfirmPassword') {
                targetInput = document.getElementById('registerConfirmPassword');
            } else if (targetId === 'LawyerPassword') {
                targetInput = document.getElementById('lawyerPassword');
            } else if (targetId === 'LawyerConfirmPassword') {
                targetInput = document.getElementById('lawyerConfirmPassword');
            }
            
            if (targetInput) {
                const type = targetInput.getAttribute('type') === 'password' ? 'text' : 'password';
                targetInput.setAttribute('type', type);
                
                // Toggle icon
                const icon = this.querySelector('i');
                if (type === 'text') {
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                } else {
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                }
            }
        });
    });
}

/**
 * Iraq-specific document generator functionality
 */
function generateIraqiDocument(documentType, formData) {
    // This would connect to the backend API in a real implementation
    console.log(`Generating ${documentType} document with data:`, formData);
    
    // Simulate document generation
    setTimeout(() => {
        alert('تم إنشاء المستند بنجاح! يمكنك تنزيله الآن.');
    }, 1500);
}

/**
 * Initialize response time options and payment section visibility
 */
function initResponseTimeOptions() {
    const responseTimeRadios = document.querySelectorAll('input[name="responseTime"]');
    const paymentOptions = document.getElementById('paymentOptions');
    const paymentMethodRadios = document.querySelectorAll('input[name="paymentMethod"]');
    const meetingScheduler = document.getElementById('meetingScheduler');
    const creditTransferReceipt = document.getElementById('creditTransferReceipt');
    
    if (responseTimeRadios.length && paymentOptions) {
        // Set initial state
        updatePaymentOptionsVisibility();
        
        // Add event listeners to response time options
        responseTimeRadios.forEach(radio => {
            radio.addEventListener('change', function() {
                updatePaymentOptionsVisibility();
            });
        });
        
        // Add event listeners to payment method options
        paymentMethodRadios.forEach(radio => {
            radio.addEventListener('change', function() {
                updateMeetingSchedulerVisibility();
                updateCreditTransferReceiptVisibility();
                
                // Set minimum date for meeting to tomorrow
                const meetingDateInput = document.getElementById('meetingDate');
                if (meetingDateInput) {
                    const tomorrow = new Date();
                    tomorrow.setDate(tomorrow.getDate() + 1);
                    meetingDateInput.min = tomorrow.toISOString().split('T')[0];
                }
            });
        });
        
        // Add validation for payment method selection
        const consultationForm = document.querySelector('#consultationModal form');
        if (consultationForm) {
            consultationForm.addEventListener('submit', function(event) {
                const selectedResponseTime = document.querySelector('input[name="responseTime"]:checked').value;
                
                // If premium response time is selected, payment method is required
                if (selectedResponseTime === 'medium' || selectedResponseTime === 'fast') {
                    const paymentMethodSelected = document.querySelector('input[name="paymentMethod"]:checked');
                    
                    if (!paymentMethodSelected) {
                        event.preventDefault();
                        event.stopPropagation();
                        
                        // Show error message
                        if (!document.getElementById('paymentErrorMessage')) {
                            const errorMessage = document.createElement('div');
                            errorMessage.id = 'paymentErrorMessage';
                            errorMessage.className = 'alert alert-danger mt-2';
                            errorMessage.textContent = 'يرجى اختيار طريقة الدفع';
                            paymentOptions.appendChild(errorMessage);
                        }
                    } else {
                        // Remove error message if exists
                        const errorMessage = document.getElementById('paymentErrorMessage');
                        if (errorMessage) {
                            errorMessage.remove();
                        }
                        
                        // If cash payment is selected, validate meeting details
                        if (paymentMethodSelected.value === 'cash') {
                            const meetingDate = document.getElementById('meetingDate');
                            const meetingTime = document.getElementById('meetingTime');
                            
                            if (!meetingDate.value || !meetingTime.value) {
                                event.preventDefault();
                                event.stopPropagation();
                                
                                // Show error message
                                if (!document.getElementById('meetingErrorMessage')) {
                                    const errorMessage = document.createElement('div');
                                    errorMessage.id = 'meetingErrorMessage';
                                    errorMessage.className = 'alert alert-danger mt-2';
                                    errorMessage.textContent = 'يرجى تحديد تاريخ ووقت المقابلة';
                                    meetingScheduler.appendChild(errorMessage);
                                }
                            } else {
                                // Remove error message if exists
                                const meetingErrorMessage = document.getElementById('meetingErrorMessage');
                                if (meetingErrorMessage) {
                                    meetingErrorMessage.remove();
                                }
                            }
                        }
                        
                        // If credit transfer is selected, validate receipt image
                        if (paymentMethodSelected.value === 'credit-transfer') {
                            const receiptImage = document.getElementById('receiptImage');
                            
                            if (!receiptImage.files.length) {
                                event.preventDefault();
                                event.stopPropagation();
                                
                                // Show error message
                                if (!document.getElementById('receiptErrorMessage')) {
                                    const errorMessage = document.createElement('div');
                                    errorMessage.id = 'receiptErrorMessage';
                                    errorMessage.className = 'alert alert-danger mt-2';
                                    errorMessage.textContent = 'يرجى إرفاق صورة الرصيد المحول';
                                    creditTransferReceipt.appendChild(errorMessage);
                                }
                            } else {
                                // Remove error message if exists
                                const receiptErrorMessage = document.getElementById('receiptErrorMessage');
                                if (receiptErrorMessage) {
                                    receiptErrorMessage.remove();
                                }
                            }
                        }
                    }
                }
            });
        }
    }
    
    // Function to update payment options visibility based on selected response time
    function updatePaymentOptionsVisibility() {
        const selectedResponseTime = document.querySelector('input[name="responseTime"]:checked').value;
        
        if (selectedResponseTime === 'medium' || selectedResponseTime === 'fast') {
            paymentOptions.classList.remove('d-none');
            
            // Make payment method required
            paymentMethodRadios.forEach(radio => {
                radio.setAttribute('required', '');
            });
            
            // Update meeting scheduler visibility
            updateMeetingSchedulerVisibility();
            // Update credit transfer receipt visibility
            updateCreditTransferReceiptVisibility();
        } else {
            paymentOptions.classList.add('d-none');
            
            // Make payment method not required
            paymentMethodRadios.forEach(radio => {
                radio.removeAttribute('required');
            });
            
            // Uncheck all payment methods
            paymentMethodRadios.forEach(radio => {
                radio.checked = false;
            });
            
            // Hide meeting scheduler
            if (meetingScheduler) {
                meetingScheduler.classList.add('d-none');
                
                // Make meeting fields not required
                const meetingFields = meetingScheduler.querySelectorAll('[required]');
                meetingFields.forEach(field => {
                    field.removeAttribute('required');
                });
            }
            
            // Hide credit transfer receipt
            if (creditTransferReceipt) {
                creditTransferReceipt.classList.add('d-none');
                
                // Make receipt image not required
                const receiptImage = document.getElementById('receiptImage');
                if (receiptImage) receiptImage.removeAttribute('required');
            }
            
            // Remove error messages if exist
            const paymentErrorMessage = document.getElementById('paymentErrorMessage');
            if (paymentErrorMessage) {
                paymentErrorMessage.remove();
            }
            
            const meetingErrorMessage = document.getElementById('meetingErrorMessage');
            if (meetingErrorMessage) {
                meetingErrorMessage.remove();
            }
            
            const receiptErrorMessage = document.getElementById('receiptErrorMessage');
            if (receiptErrorMessage) {
                receiptErrorMessage.remove();
            }
        }
    }
    
    // Function to update meeting scheduler visibility based on selected payment method
    function updateMeetingSchedulerVisibility() {
        const selectedPaymentMethod = document.querySelector('input[name="paymentMethod"]:checked');
        
        if (meetingScheduler) {
            if (selectedPaymentMethod && selectedPaymentMethod.value === 'cash') {
                meetingScheduler.classList.remove('d-none');
                
                // Make meeting fields required
                const meetingDate = document.getElementById('meetingDate');
                const meetingTime = document.getElementById('meetingTime');
                
                if (meetingDate) meetingDate.setAttribute('required', '');
                if (meetingTime) meetingTime.setAttribute('required', '');
            } else {
                meetingScheduler.classList.add('d-none');
                
                // Make meeting fields not required
                const meetingFields = meetingScheduler.querySelectorAll('[required]');
                meetingFields.forEach(field => {
                    field.removeAttribute('required');
                });
                
                // Remove error message if exists
                const meetingErrorMessage = document.getElementById('meetingErrorMessage');
                if (meetingErrorMessage) {
                    meetingErrorMessage.remove();
                }
            }
        }
    }
    
    // Function to update credit transfer receipt visibility based on selected payment method
    function updateCreditTransferReceiptVisibility() {
        const selectedPaymentMethod = document.querySelector('input[name="paymentMethod"]:checked');
        
        if (creditTransferReceipt) {
            if (selectedPaymentMethod && selectedPaymentMethod.value === 'credit-transfer') {
                creditTransferReceipt.classList.remove('d-none');
                
                // Make receipt image required
                const receiptImage = document.getElementById('receiptImage');
                if (receiptImage) receiptImage.setAttribute('required', '');
            } else {
                creditTransferReceipt.classList.add('d-none');
                
                // Make receipt image not required
                const receiptImage = document.getElementById('receiptImage');
                if (receiptImage) receiptImage.removeAttribute('required');
                
                // Remove error message if exists
                const receiptErrorMessage = document.getElementById('receiptErrorMessage');
                if (receiptErrorMessage) {
                    receiptErrorMessage.remove();
                }
            }
        }
    }
}
