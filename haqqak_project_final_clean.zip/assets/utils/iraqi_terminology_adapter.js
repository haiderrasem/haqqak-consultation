// ملف تطبيق المصطلحات العراقية
const iraqiTerminology = require('./terminology/iraqi_legal_terms.json');

/**
 * تطبيق المصطلحات العراقية على واجهة المستخدم والمحتوى
 * @param {string} text - النص المراد تعديله
 * @param {string} context - سياق النص (legal أو payment)
 * @returns {string} - النص بعد تطبيق المصطلحات العراقية
 */
function applyIraqiTerminology(text, context = 'legal') {
  if (!text) return text;
  
  let modifiedText = text;
  const termsCollection = context === 'payment' ? iraqiTerminology.payment_terms : iraqiTerminology.legal_terms;
  
  // استبدال المصطلحات القياسية بالمصطلحات العراقية
  Object.keys(termsCollection).forEach(key => {
    const standardTerm = termsCollection[key].standard;
    const iraqiTerm = termsCollection[key].iraqi;
    
    // استخدام تعبير منتظم للبحث عن الكلمة كاملة فقط
    const regex = new RegExp(`\\b${standardTerm}\\b`, 'g');
    modifiedText = modifiedText.replace(regex, iraqiTerm);
  });
  
  return modifiedText;
}

/**
 * تطبيق المصطلحات العراقية على كائن JSON
 * @param {Object} jsonObj - كائن JSON المراد تعديله
 * @param {string} context - سياق النص (legal أو payment)
 * @returns {Object} - كائن JSON بعد تطبيق المصطلحات العراقية
 */
function applyIraqiTerminologyToJSON(jsonObj, context = 'legal') {
  if (!jsonObj) return jsonObj;
  
  // نسخة عميقة من الكائن لتجنب تعديل الكائن الأصلي
  const modifiedObj = JSON.parse(JSON.stringify(jsonObj));
  
  // معالجة الكائن بشكل تكراري
  function processObject(obj) {
    if (typeof obj !== 'object' || obj === null) return obj;
    
    if (Array.isArray(obj)) {
      return obj.map(item => processObject(item));
    }
    
    const result = {};
    for (const key in obj) {
      if (typeof obj[key] === 'string') {
        result[key] = applyIraqiTerminology(obj[key], context);
      } else if (typeof obj[key] === 'object' && obj[key] !== null) {
        result[key] = processObject(obj[key]);
      } else {
        result[key] = obj[key];
      }
    }
    
    return result;
  }
  
  return processObject(modifiedObj);
}

/**
 * تطبيق المصطلحات العراقية على قالب مستند
 * @param {Object} template - قالب المستند المراد تعديله
 * @returns {Object} - قالب المستند بعد تطبيق المصطلحات العراقية
 */
function applyIraqiTerminologyToTemplate(template) {
  if (!template) return template;
  
  const modifiedTemplate = JSON.parse(JSON.stringify(template));
  
  // تطبيق المصطلحات على نص القالب
  if (modifiedTemplate.template_text) {
    modifiedTemplate.template_text = applyIraqiTerminology(modifiedTemplate.template_text, 'legal');
  }
  
  // تطبيق المصطلحات على الحقول
  if (modifiedTemplate.fields && Array.isArray(modifiedTemplate.fields)) {
    modifiedTemplate.fields = modifiedTemplate.fields.map(field => {
      if (field.label) {
        field.label = applyIraqiTerminology(field.label, 'legal');
      }
      if (field.placeholder) {
        field.placeholder = applyIraqiTerminology(field.placeholder, 'legal');
      }
      if (field.description) {
        field.description = applyIraqiTerminology(field.description, 'legal');
      }
      if (field.options && Array.isArray(field.options)) {
        field.options = field.options.map(option => {
          if (option.label) {
            option.label = applyIraqiTerminology(option.label, 'legal');
          }
          return option;
        });
      }
      return field;
    });
  }
  
  return modifiedTemplate;
}

/**
 * تطبيق المصطلحات العراقية على واجهة المستخدم
 * @param {Object} uiComponents - مكونات واجهة المستخدم
 * @returns {Object} - مكونات واجهة المستخدم بعد تطبيق المصطلحات العراقية
 */
function applyIraqiTerminologyToUI(uiComponents) {
  // تطبيق المصطلحات القانونية
  const legalUI = applyIraqiTerminologyToJSON(uiComponents, 'legal');
  
  // تطبيق مصطلحات الدفع
  return applyIraqiTerminologyToJSON(legalUI, 'payment');
}

module.exports = {
  applyIraqiTerminology,
  applyIraqiTerminologyToJSON,
  applyIraqiTerminologyToTemplate,
  applyIraqiTerminologyToUI
};
