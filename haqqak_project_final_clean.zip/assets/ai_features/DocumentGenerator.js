// ميزات الذكاء الاصطناعي - مولد المستندات القانونية
import React, { useState, useEffect, useRef } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TextInput, 
  TouchableOpacity, 
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Share
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import DocumentPicker from 'react-native-document-picker';
import RNFS from 'react-native-fs';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { API_URL } from '../../config';
import { useAuth } from '../../contexts/AuthContext';
import DropdownSelect from '../../components/UI/DropdownSelect';
import PrimaryButton from '../../components/UI/PrimaryButton';
import SecondaryButton from '../../components/UI/SecondaryButton';

const DocumentGenerator = () => {
  const navigation = useNavigation();
  const { user } = useAuth();
  
  const [documentType, setDocumentType] = useState('');
  const [documentDetails, setDocumentDetails] = useState({});
  const [uploadedDocument, setUploadedDocument] = useState(null);
  const [generatedDocument, setGeneratedDocument] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [step, setStep] = useState(1);
  
  const documentTypes = [
    { label: 'عقد عمل', value: 'employment_contract' },
    { label: 'عقد إيجار', value: 'rental_agreement' },
    { label: 'خطاب إنذار', value: 'warning_letter' },
    { label: 'توكيل قانوني', value: 'power_of_attorney' },
    { label: 'اتفاقية عدم إفشاء', value: 'non_disclosure_agreement' },
    { label: 'اتفاقية تسوية', value: 'settlement_agreement' },
    { label: 'شكوى قانونية', value: 'legal_complaint' },
    { label: 'استقالة', value: 'resignation_letter' }
  ];
  
  useEffect(() => {
    // إعداد عنوان الصفحة
    navigation.setOptions({
      title: 'مولد المستندات القانونية',
    });
  }, []);
  
  const getDocumentFields = () => {
    switch (documentType) {
      case 'employment_contract':
        return [
          { key: 'employer_name', label: 'اسم صاحب العمل', type: 'text', required: true },
          { key: 'employee_name', label: 'اسم الموظف', type: 'text', required: true },
          { key: 'position', label: 'المسمى الوظيفي', type: 'text', required: true },
          { key: 'salary', label: 'الراتب الشهري', type: 'number', required: true },
          { key: 'start_date', label: 'تاريخ بدء العمل', type: 'date', required: true },
          { key: 'contract_duration', label: 'مدة العقد (بالشهور)', type: 'number', required: true },
          { key: 'working_hours', label: 'ساعات العمل اليومية', type: 'number', required: true },
          { key: 'probation_period', label: 'فترة التجربة (بالشهور)', type: 'number', required: true },
          { key: 'additional_benefits', label: 'المزايا الإضافية', type: 'textarea', required: false }
        ];
      case 'rental_agreement':
        return [
          { key: 'landlord_name', label: 'اسم المؤجر', type: 'text', required: true },
          { key: 'tenant_name', label: 'اسم المستأجر', type: 'text', required: true },
          { key: 'property_address', label: 'عنوان العقار', type: 'textarea', required: true },
          { key: 'rent_amount', label: 'قيمة الإيجار الشهري', type: 'number', required: true },
          { key: 'start_date', label: 'تاريخ بدء العقد', type: 'date', required: true },
          { key: 'end_date', label: 'تاريخ انتهاء العقد', type: 'date', required: true },
          { key: 'security_deposit', label: 'قيمة التأمين', type: 'number', required: true },
          { key: 'payment_method', label: 'طريقة الدفع', type: 'text', required: true },
          { key: 'additional_terms', label: 'شروط إضافية', type: 'textarea', required: false }
        ];
      case 'warning_letter':
        return [
          { key: 'sender_name', label: 'اسم المرسل', type: 'text', required: true },
          { key: 'recipient_name', label: 'اسم المستلم', type: 'text', required: true },
          { key: 'warning_reason', label: 'سبب الإنذار', type: 'textarea', required: true },
          { key: 'warning_date', label: 'تاريخ الإنذار', type: 'date', required: true },
          { key: 'correction_period', label: 'فترة التصحيح (بالأيام)', type: 'number', required: true },
          { key: 'consequences', label: 'العواقب المترتبة على عدم الالتزام', type: 'textarea', required: true }
        ];
      // يمكن إضافة المزيد من أنواع المستندات هنا
      default:
        return [];
    }
  };
  
  const handleDocumentTypeChange = (value) => {
    setDocumentType(value);
    setDocumentDetails({});
    setError('');
  };
  
  const handleInputChange = (key, value) => {
    setDocumentDetails(prevDetails => ({
      ...prevDetails,
      [key]: value
    }));
  };
  
  const validateFields = () => {
    const fields = getDocumentFields();
    const missingFields = fields
      .filter(field => field.required && !documentDetails[field.key])
      .map(field => field.label);
    
    if (missingFields.length > 0) {
      setError(`يرجى ملء الحقول المطلوبة: ${missingFields.join('، ')}`);
      return false;
    }
    
    return true;
  };
  
  const handleUploadDocument = async () => {
    try {
      const result = await DocumentPicker.pick({
        type: [DocumentPicker.types.doc, DocumentPicker.types.docx, DocumentPicker.types.pdf],
      });
      
      setUploadedDocument(result[0]);
      setError('');
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
        // المستخدم ألغى العملية
      } else {
        console.error('خطأ في اختيار المستند:', err);
        setError('حدث خطأ أثناء اختيار المستند. يرجى المحاولة مرة أخرى.');
      }
    }
  };
  
  const handleGenerateDocument = async () => {
    if (documentType && validateFields()) {
      try {
        setLoading(true);
        setError('');
        
        const token = await AsyncStorage.getItem('token');
        
        const formData = new FormData();
        formData.append('document_type', documentType);
        formData.append('details', JSON.stringify(documentDetails));
        
        if (uploadedDocument) {
          formData.append('uploaded_document', {
            uri: uploadedDocument.uri,
            type: uploadedDocument.type,
            name: uploadedDocument.name
          });
        }
        
        const response = await axios.post(
          `${API_URL}/api/ai/generate-document`,
          formData,
          {
            headers: {
              'Content-Type': 'multipart/form-data',
              Authorization: token ? `Bearer ${token}` : undefined
            }
          }
        );
        
        if (response.data.success) {
          setGeneratedDocument(response.data.data);
          setStep(3);
        } else {
          setError(response.data.message || 'فشل إنشاء المستند');
        }
      } catch (error) {
        console.error('خطأ في إنشاء المستند:', error);
        setError('حدث خطأ أثناء إنشاء المستند. يرجى المحاولة مرة أخرى.');
      } finally {
        setLoading(false);
      }
    }
  };
  
  const handleAnalyzeDocument = async () => {
    if (uploadedDocument) {
      try {
        setLoading(true);
        setError('');
        
        const token = await AsyncStorage.getItem('token');
        
        const formData = new FormData();
        formData.append('document', {
          uri: uploadedDocument.uri,
          type: uploadedDocument.type,
          name: uploadedDocument.name
        });
        
        const response = await axios.post(
          `${API_URL}/api/ai/analyze-document`,
          formData,
          {
            headers: {
              'Content-Type': 'multipart/form-data',
              Authorization: token ? `Bearer ${token}` : undefined
            }
          }
        );
        
        if (response.data.success) {
          // تحديد نوع المستند تلقائياً
          if (response.data.data.document_type) {
            setDocumentType(response.data.data.document_type);
          }
          
          // ملء التفاصيل المستخرجة
          setDocumentDetails(response.data.data.details || {});
          
          setStep(2);
        } else {
          setError(response.data.message || 'فشل تحليل المستند');
        }
      } catch (error) {
        console.error('خطأ في تحليل المستند:', error);
        setError('حدث خطأ أثناء تحليل المستند. يرجى المحاولة مرة أخرى.');
      } finally {
        setLoading(false);
      }
    } else {
      setError('يرجى اختيار مستند للتحليل أولاً');
    }
  };
  
  const handleDownloadDocument = async () => {
    if (generatedDocument && generatedDocument.document_url) {
      try {
        setLoading(true);
        
        // تحديد مسار الحفظ
        const downloadPath = `${RNFS.DocumentDirectoryPath}/${generatedDocument.document_name}`;
        
        // تنزيل الملف
        const result = await RNFS.downloadFile({
          fromUrl: generatedDocument.document_url,
          toFile: downloadPath,
        }).promise;
        
        if (result.statusCode === 200) {
          Alert.alert(
            'تم التنزيل بنجاح',
            `تم حفظ المستند في: ${downloadPath}`,
            [{ text: 'حسناً' }]
          );
        } else {
          setError('فشل تنزيل المستند');
        }
      } catch (error) {
        console.error('خطأ في تنزيل المستند:', error);
        setError('حدث خطأ أثناء تنزيل المستند. يرجى المحاولة مرة أخرى.');
      } finally {
        setLoading(false);
      }
    }
  };
  
  const handleShareDocument = async () => {
    if (generatedDocument && generatedDocument.document_url) {
      try {
        await Share.share({
          title: generatedDocument.document_name,
          url: generatedDocument.document_url,
          message: `مشاركة مستند: ${generatedDocument.document_name}`
        });
      } catch (error) {
        console.error('خطأ في مشاركة المستند:', error);
        setError('حدث خطأ أثناء مشاركة المستند. يرجى المحاولة مرة أخرى.');
      }
    }
  };
  
  const renderStep1 = () => (
    <View style={styles.stepContainer}>
      <Text style={styles.stepTitle}>الخطوة 1: اختيار نوع المستند</Text>
      
      <View style={styles.optionsContainer}>
        <View style={styles.optionCard}>
          <Icon name="description" size={40} color="#1976d2" />
          <Text style={styles.optionTitle}>إنشاء مستند جديد</Text>
          <Text style={styles.optionDescription}>
            اختر نوع المستند وأدخل التفاصيل المطلوبة لإنشاء مستند قانوني جديد
          </Text>
          
          <View style={styles.dropdownContainer}>
            <DropdownSelect
              label="اختر نوع المستند"
              items={documentTypes}
              value={documentType}
              onValueChange={handleDocumentTypeChange}
              placeholder="اختر نوع المستند"
            />
          </View>
          
          <PrimaryButton
            title="متابعة"
            onPress={() => setStep(2)}
            disabled={!documentType}
          />
        </View>
        
        <View style={styles.optionDivider} />
        
        <View style={styles.optionCard}>
          <Icon name="upload-file" size={40} color="#1976d2" />
          <Text style={styles.optionTitle}>تحليل مستند موجود</Text>
          <Text style={styles.optionDescription}>
            قم بتحميل مستند موجود لتحليله وتعديله أو استخدامه كقالب
          </Text>
          
          <TouchableOpacity
            style={styles.uploadButton}
            onPress={handleUploadDocument}
          >
            <Icon name="file-upload" size={24} color="#1976d2" />
            <Text style={styles.uploadButtonText}>
              {uploadedDocument ? uploadedDocument.name : 'اختيار ملف'}
            </Text>
          </TouchableOpacity>
          
          <PrimaryButton
            title="تحليل المستند"
            onPress={handleAnalyzeDocument}
            disabled={!uploadedDocument || loading}
            loading={loading}
          />
        </View>
      </View>
    </View>
  );
  
  const renderStep2 = () => (
    <KeyboardAvoidingView
      style={styles.stepContainer}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
    >
      <Text style={styles.stepTitle}>الخطوة 2: إدخال تفاصيل المستند</Text>
      
      <ScrollView style={styles.formContainer}>
        {getDocumentFields().map((field) => (
          <View key={field.key} style={styles.formField}>
            <Text style={styles.fieldLabel}>
              {field.label}
              {field.required && <Text style={styles.requiredMark}>*</Text>}
            </Text>
            
            {field.type === 'textarea' ? (
              <TextInput
                style={styles.textareaInput}
                value={documentDetails[field.key] || ''}
                onChangeText={(value) => handleInputChange(field.key, value)}
                multiline
                numberOfLines={4}
                textAlignVertical="top"
                placeholder={`أدخل ${field.label}`}
                placeholderTextColor="#999"
              />
            ) : field.type === 'date' ? (
              <TouchableOpacity
                style={styles.dateInput}
                onPress={() => {
                  // يمكن استخدام مكتبة DateTimePicker هنا
                  // للتبسيط، نستخدم حقل نص عادي
                  Alert.alert('ملاحظة', 'يرجى إدخال التاريخ بصيغة YYYY-MM-DD');
                }}
              >
                <TextInput
                  style={styles.dateInputText}
                  value={documentDetails[field.key] || ''}
                  onChangeText={(value) => handleInputChange(field.key, value)}
                  placeholder="YYYY-MM-DD"
                  placeholderTextColor="#999"
                />
                <Icon name="calendar-today" size={20} color="#666" />
              </TouchableOpacity>
            ) : (
              <TextInput
                style={styles.textInput}
                value={documentDetails[field.key] || ''}
                onChangeText={(value) => handleInputChange(field.key, value)}
                keyboardType={field.type === 'number' ? 'numeric' : 'default'}
                placeholder={`أدخل ${field.label}`}
                placeholderTextColor="#999"
              />
            )}
          </View>
        ))}
      </ScrollView>
      
      <View style={styles.actionsContainer}>
        <PrimaryButton
          title="إنشاء المستند"
          onPress={handleGenerateDocument}
          disabled={loading}
          loading={loading}
        />
        
        <SecondaryButton
          title="رجوع"
          onPress={() => setStep(1)}
          disabled={loading}
        />
      </View>
    </KeyboardAvoidingView>
  );
  
  const renderStep3 = () => (
    <View style={styles.stepContainer}>
      <Text style={styles.stepTitle}>الخطوة 3: المستند الجاهز</Text>
      
      {generatedDocument && (
        <View style={styles.documentPreviewContainer}>
          <Icon name="description" size={60} color="#1976d2" />
          
          <Text style={styles.documentName}>
            {generatedDocument.document_name}
          </Text>
          
          <Text style={styles.documentInfo}>
            النوع: {documentTypes.find(type => type.value === documentType)?.label || documentType}
          </Text>
          
          <Text style={styles.documentInfo}>
            تاريخ الإنشاء: {new Date().toLocaleDateString('ar-SA')}
          </Text>
          
          <View style={styles.documentActionsContainer}>
            <TouchableOpacity
              style={styles.documentAction}
              onPress={handleDownloadDocument}
              disabled={loading}
            >
              <Icon name="file-download" size={24} color="#1976d2" />
              <Text style={styles.documentActionText}>تنزيل</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={styles.documentAction}
              onPress={handleShareDocument}
              disabled={loading}
            >
              <Icon name="share" size={24} color="#1976d2" />
              <Text style={styles.documentActionText}>مشاركة</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={styles.documentAction}
              onPress={() => {
                // فتح المستند للمعاينة
                if (generatedDocument.document_url) {
                  navigation.navigate('معاينة المستند', {
                    url: generatedDocument.document_url,
                    title: generatedDocument.document_name
                  });
                }
              }}
              disabled={loading}
            >
              <Icon name="visibility" size={24} color="#1976d2" />
              <Text style={styles.documentActionText}>معاينة</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
      
      <View style={styles.actionsContainer}>
        <PrimaryButton
          title="إنشاء مستند جديد"
          onPress={() => {
            setStep(1);
            setDocumentType('');
            setDocumentDetails({});
            setUploadedDocument(null);
            setGeneratedDocument(null);
          }}
        />
      </View>
    </View>
  );
  
  return (
    <View style={styles.container}>
      {error ? (
        <View style={styles.errorContainer}>
          <Icon name="error-outline" size={20} color="#f44336" />
          <Text style={styles.errorText}>{error}</Text>
        </View>
      ) : null}
      
      <View style={styles.stepsIndicatorContainer}>
        {[1, 2, 3].map((stepNumber) => (
          <View
            key={`step-${stepNumber}`}
            style={[
              styles.stepIndicator,
              step >= stepNumber ? styles.stepIndicatorActive : {}
            ]}
          >
            <Text
              style={[
                styles.stepIndicatorText,
                step >= stepNumber ? styles.stepIndicatorTextActive : {}
              ]}
            >
              {stepNumber}
            </Text>
          </View>
        ))}
      </View>
      
      {step === 1 && renderStep1()}
      {step === 2 && renderStep2()}
      {step === 3 && renderStep3()}
      
      <View style={styles.disclaimerContainer}>
        <Icon name="info-outline" size={16} color="#666" />
        <Text style={styles.disclaimerText}>
          المستندات المنشأة هي لأغراض إرشادية فقط وقد تتطلب مراجعة من محامٍ مؤهل.
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  stepContainer: {
    flex: 1,
    padding: 15,
  },
  stepsIndicatorContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 15,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  stepIndicator: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#f0f0f0',
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 10,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  stepIndicatorActive: {
    backgroundColor: '#1976d2',
    borderColor: '#1976d2',
  },
  stepIndicatorText: {
    fontFamily: 'Cairo-Bold',
    fontSize: 14,
    color: '#666',
  },
  stepIndicatorTextActive: {
    color: '#fff',
  },
  stepTitle: {
    fontFamily: 'Cairo-Bold',
    fontSize: 18,
    color: '#333',
    marginBottom: 15,
    textAlign: 'center',
  },
  optionsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'stretch',
    marginBottom: 20,
  },
  optionCard: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  optionDivider: {
    width: 15,
  },
  optionTitle: {
    fontFamily: 'Cairo-Bold',
    fontSize: 16,
    color: '#333',
    marginTop: 10,
    marginBottom: 5,
    textAlign: 'center',
  },
  optionDescription: {
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#666',
    marginBottom: 15,
    textAlign: 'center',
  },
  dropdownContainer: {
    width: '100%',
    marginBottom: 15,
  },
  uploadButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 10,
    borderWidth: 1,
    borderColor: '#1976d2',
    borderRadius: 5,
    marginBottom: 15,
    width: '100%',
  },
  uploadButtonText: {
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#1976d2',
    marginRight: 10,
  },
  formContainer: {
    flex: 1,
    marginBottom: 15,
  },
  formField: {
    marginBottom: 15,
  },
  fieldLabel: {
    fontFamily: 'Cairo-Bold',
    fontSize: 14,
    color: '#333',
    marginBottom: 5,
    textAlign: 'right',
  },
  requiredMark: {
    color: '#f44336',
    marginRight: 5,
  },
  textInput: {
    backgroundColor: '#f0f0f0',
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ddd',
    padding: 10,
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#333',
    textAlign: 'right',
  },
  textareaInput: {
    backgroundColor: '#f0f0f0',
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ddd',
    padding: 10,
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#333',
    textAlign: 'right',
    minHeight: 100,
  },
  dateInput: {
    backgroundColor: '#f0f0f0',
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ddd',
    padding: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  dateInputText: {
    flex: 1,
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#333',
    textAlign: 'right',
  },
  actionsContainer: {
    marginTop: 15,
  },
  documentPreviewContainer: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 20,
    alignItems: 'center',
    marginBottom: 20,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  documentName: {
    fontFamily: 'Cairo-Bold',
    fontSize: 18,
    color: '#333',
    marginTop: 15,
    marginBottom: 5,
    textAlign: 'center',
  },
  documentInfo: {
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
    textAlign: 'center',
  },
  documentActionsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginTop: 20,
  },
  documentAction: {
    alignItems: 'center',
    padding: 10,
  },
  documentActionText: {
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#1976d2',
    marginTop: 5,
  },
  disclaimerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    padding: 10,
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
  },
  disclaimerText: {
    fontFamily: 'Cairo-Regular',
    fontSize: 12,
    color: '#666',
    marginRight: 5,
    flex: 1,
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffebee',
    padding: 10,
    margin: 10,
    borderRadius: 5,
  },
  errorText: {
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#f44336',
    marginRight: 10,
    flex: 1,
  },
});

export default DocumentGenerator;
