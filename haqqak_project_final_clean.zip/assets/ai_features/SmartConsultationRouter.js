// ميزات الذكاء الاصطناعي - نظام توجيه الاستشارات الذكي (معدل للقوانين العراقية)
import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TextInput, 
  TouchableOpacity, 
  ActivityIndicator,
  Alert
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { API_URL } from '../../config';
import { useAuth } from '../../contexts/AuthContext';
import DropdownSelect from '../../components/UI/DropdownSelect';
import PrimaryButton from '../../components/UI/PrimaryButton';
import SecondaryButton from '../../components/UI/SecondaryButton';
import LawyerCard from '../../components/Lawyers/LawyerCard';

const SmartConsultationRouter = () => {
  const navigation = useNavigation();
  const { user } = useAuth();
  
  const [consultationTitle, setConsultationTitle] = useState('');
  const [consultationDetails, setConsultationDetails] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [urgencyLevel, setUrgencyLevel] = useState('medium');
  const [loading, setLoading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState('');
  const [analysisResults, setAnalysisResults] = useState(null);
  const [recommendedLawyers, setRecommendedLawyers] = useState([]);
  
  // قائمة التخصصات القانونية في العراق
  const legalCategories = [
    { label: 'القانون المدني', value: 'civil_law' },
    { label: 'القانون الجنائي', value: 'criminal_law' },
    { label: 'قانون الأحوال الشخصية', value: 'personal_status_law' },
    { label: 'قانون العمل', value: 'labor_law' },
    { label: 'القانون التجاري', value: 'commercial_law' },
    { label: 'قانون العقارات', value: 'real_estate_law' },
    { label: 'قانون الملكية الفكرية', value: 'intellectual_property_law' },
    { label: 'قانون الضرائب', value: 'tax_law' },
    { label: 'قانون الشركات', value: 'corporate_law' },
    { label: 'قانون الإدارة العامة', value: 'administrative_law' },
    { label: 'قانون الأسرة والميراث', value: 'family_inheritance_law' },
    { label: 'قانون الهجرة واللجوء', value: 'immigration_asylum_law' },
    { label: 'قانون الطاقة والنفط', value: 'energy_oil_law' },
    { label: 'قانون البيئة', value: 'environmental_law' },
    { label: 'أخرى', value: 'other' }
  ];
  
  const urgencyLevels = [
    { label: 'عاجل جداً', value: 'high' },
    { label: 'عاجل', value: 'medium' },
    { label: 'غير عاجل', value: 'low' }
  ];
  
  useEffect(() => {
    // إعداد عنوان الصفحة
    navigation.setOptions({
      title: 'توجيه الاستشارة القانونية',
    });
  }, []);
  
  const handleAnalyzeConsultation = async () => {
    if (!consultationTitle.trim() || !consultationDetails.trim()) {
      setError('يرجى إدخال عنوان وتفاصيل الاستشارة');
      return;
    }
    
    try {
      setAnalyzing(true);
      setError('');
      
      const token = await AsyncStorage.getItem('token');
      
      const response = await axios.post(
        `${API_URL}/api/ai/analyze-consultation`,
        {
          title: consultationTitle,
          details: consultationDetails
        },
        {
          headers: {
            Authorization: token ? `Bearer ${token}` : undefined
          }
        }
      );
      
      if (response.data.success) {
        setAnalysisResults(response.data.data);
        
        // تحديد التخصص تلقائياً بناءً على التحليل
        if (response.data.data.recommended_category) {
          setSelectedCategory(response.data.data.recommended_category);
        }
        
        // تحديد مستوى الأولوية تلقائياً بناءً على التحليل
        if (response.data.data.urgency_level) {
          setUrgencyLevel(response.data.data.urgency_level);
        }
        
        // البحث عن المحامين الموصى بهم
        fetchRecommendedLawyers(response.data.data.recommended_category);
      } else {
        setError(response.data.message || 'فشل تحليل الاستشارة');
      }
    } catch (error) {
      console.error('خطأ في تحليل الاستشارة:', error);
      setError('حدث خطأ أثناء تحليل الاستشارة. يرجى المحاولة مرة أخرى.');
    } finally {
      setAnalyzing(false);
    }
  };
  
  const fetchRecommendedLawyers = async (category) => {
    try {
      setLoading(true);
      
      const token = await AsyncStorage.getItem('token');
      
      const response = await axios.get(
        `${API_URL}/api/lawyers/recommended`,
        {
          params: {
            category: category || selectedCategory,
            urgency: urgencyLevel
          },
          headers: {
            Authorization: token ? `Bearer ${token}` : undefined
          }
        }
      );
      
      if (response.data.success) {
        setRecommendedLawyers(response.data.data);
      } else {
        console.error('فشل جلب المحامين الموصى بهم:', response.data.message);
      }
    } catch (error) {
      console.error('خطأ في جلب المحامين الموصى بهم:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const handleCategoryChange = (value) => {
    setSelectedCategory(value);
    
    // إعادة البحث عن المحامين عند تغيير التخصص
    if (analysisResults) {
      fetchRecommendedLawyers(value);
    }
  };
  
  const handleUrgencyChange = (value) => {
    setUrgencyLevel(value);
    
    // إعادة البحث عن المحامين عند تغيير مستوى الأولوية
    if (analysisResults) {
      fetchRecommendedLawyers(selectedCategory);
    }
  };
  
  const handleSubmitConsultation = async (lawyerId) => {
    try {
      setLoading(true);
      setError('');
      
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        navigation.navigate('تسجيل الدخول');
        return;
      }
      
      const response = await axios.post(
        `${API_URL}/api/consultations`,
        {
          title: consultationTitle,
          details: consultationDetails,
          category: selectedCategory,
          urgency_level: urgencyLevel,
          lawyer_id: lawyerId
        },
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );
      
      if (response.data.success) {
        Alert.alert(
          'تم إرسال الاستشارة',
          'تم إرسال استشارتك بنجاح. سيتم إشعارك عندما يقوم المحامي بالرد.',
          [
            {
              text: 'حسناً',
              onPress: () => {
                // الانتقال إلى صفحة تفاصيل الاستشارة
                navigation.navigate('تفاصيل الاستشارة', {
                  consultationId: response.data.data._id
                });
              }
            }
          ]
        );
      } else {
        setError(response.data.message || 'فشل إرسال الاستشارة');
      }
    } catch (error) {
      console.error('خطأ في إرسال الاستشارة:', error);
      setError('حدث خطأ أثناء إرسال الاستشارة. يرجى المحاولة مرة أخرى.');
    } finally {
      setLoading(false);
    }
  };
  
  const renderAnalysisResults = () => (
    <View style={styles.analysisResultsContainer}>
      <Text style={styles.sectionTitle}>نتائج التحليل</Text>
      
      <View style={styles.analysisItem}>
        <Text style={styles.analysisLabel}>القضايا القانونية المحتملة:</Text>
        <View style={styles.tagContainer}>
          {analysisResults.legal_issues.map((issue, index) => (
            <View key={`issue-${index}`} style={styles.tag}>
              <Text style={styles.tagText}>{issue}</Text>
            </View>
          ))}
        </View>
      </View>
      
      <View style={styles.analysisItem}>
        <Text style={styles.analysisLabel}>التخصص القانوني الموصى به:</Text>
        <Text style={styles.analysisValue}>
          {legalCategories.find(cat => cat.value === analysisResults.recommended_category)?.label || analysisResults.recommended_category}
        </Text>
      </View>
      
      <View style={styles.analysisItem}>
        <Text style={styles.analysisLabel}>مستوى الأولوية المقترح:</Text>
        <Text style={styles.analysisValue}>
          {urgencyLevels.find(level => level.value === analysisResults.urgency_level)?.label || analysisResults.urgency_level}
        </Text>
      </View>
      
      {analysisResults.relevant_laws && analysisResults.relevant_laws.length > 0 && (
        <View style={styles.analysisItem}>
          <Text style={styles.analysisLabel}>القوانين العراقية ذات الصلة:</Text>
          {analysisResults.relevant_laws.map((law, index) => (
            <Text key={`law-${index}`} style={styles.lawText}>
              • {law}
            </Text>
          ))}
        </View>
      )}
      
      {analysisResults.additional_notes && (
        <View style={styles.analysisItem}>
          <Text style={styles.analysisLabel}>ملاحظات إضافية:</Text>
          <Text style={styles.analysisValue}>{analysisResults.additional_notes}</Text>
        </View>
      )}
    </View>
  );
  
  const renderRecommendedLawyers = () => (
    <View style={styles.recommendedLawyersContainer}>
      <Text style={styles.sectionTitle}>المحامون الموصى بهم</Text>
      
      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="small" color="#1976d2" />
          <Text style={styles.loadingText}>جاري البحث عن المحامين المناسبين...</Text>
        </View>
      ) : recommendedLawyers.length > 0 ? (
        recommendedLawyers.map((lawyer) => (
          <LawyerCard
            key={lawyer._id}
            lawyer={lawyer}
            onPress={() => {
              // عرض تأكيد قبل إرسال الاستشارة
              Alert.alert(
                'تأكيد إرسال الاستشارة',
                `هل أنت متأكد من رغبتك في إرسال استشارتك إلى المحامي ${lawyer.name}؟`,
                [
                  {
                    text: 'إلغاء',
                    style: 'cancel'
                  },
                  {
                    text: 'إرسال',
                    onPress: () => handleSubmitConsultation(lawyer._id)
                  }
                ]
              );
            }}
            showConsultButton={true}
          />
        ))
      ) : (
        <View style={styles.emptyStateContainer}>
          <Icon name="search-off" size={40} color="#b0bec5" />
          <Text style={styles.emptyStateText}>
            لم يتم العثور على محامين متخصصين في هذا المجال حالياً
          </Text>
        </View>
      )}
    </View>
  );
  
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      {error ? (
        <View style={styles.errorContainer}>
          <Icon name="error-outline" size={20} color="#f44336" />
          <Text style={styles.errorText}>{error}</Text>
        </View>
      ) : null}
      
      <View style={styles.formContainer}>
        <Text style={styles.sectionTitle}>تفاصيل الاستشارة</Text>
        
        <View style={styles.formField}>
          <Text style={styles.fieldLabel}>عنوان الاستشارة</Text>
          <TextInput
            style={styles.textInput}
            value={consultationTitle}
            onChangeText={setConsultationTitle}
            placeholder="أدخل عنواناً موجزاً للاستشارة"
            placeholderTextColor="#999"
          />
        </View>
        
        <View style={styles.formField}>
          <Text style={styles.fieldLabel}>تفاصيل الاستشارة</Text>
          <TextInput
            style={styles.textareaInput}
            value={consultationDetails}
            onChangeText={setConsultationDetails}
            multiline
            numberOfLines={6}
            textAlignVertical="top"
            placeholder="اشرح قضيتك القانونية بالتفصيل..."
            placeholderTextColor="#999"
          />
        </View>
        
        <PrimaryButton
          title={analyzing ? 'جاري التحليل...' : 'تحليل الاستشارة'}
          onPress={handleAnalyzeConsultation}
          disabled={!consultationTitle.trim() || !consultationDetails.trim() || analyzing}
          loading={analyzing}
        />
      </View>
      
      {analysisResults && (
        <>
          {renderAnalysisResults()}
          
          <View style={styles.formContainer}>
            <Text style={styles.sectionTitle}>تأكيد التفاصيل</Text>
            
            <View style={styles.formField}>
              <Text style={styles.fieldLabel}>التخصص القانوني</Text>
              <DropdownSelect
                label="اختر التخصص القانوني"
                items={legalCategories}
                value={selectedCategory}
                onValueChange={handleCategoryChange}
                placeholder="اختر التخصص القانوني"
              />
            </View>
            
            <View style={styles.formField}>
              <Text style={styles.fieldLabel}>مستوى الأولوية</Text>
              <DropdownSelect
                label="اختر مستوى الأولوية"
                items={urgencyLevels}
                value={urgencyLevel}
                onValueChange={handleUrgencyChange}
                placeholder="اختر مستوى الأولوية"
              />
            </View>
          </View>
          
          {renderRecommendedLawyers()}
        </>
      )}
      
      <View style={styles.disclaimerContainer}>
        <Icon name="info-outline" size={16} color="#666" />
        <Text style={styles.disclaimerText}>
          يستخدم هذا النظام الذكاء الاصطناعي لتحليل استشارتك وتوجيهك إلى المحامين المناسبين وفقاً للقوانين العراقية.
        </Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  contentContainer: {
    padding: 15,
    paddingBottom: 30,
  },
  formContainer: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 20,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  sectionTitle: {
    fontFamily: 'Cairo-Bold',
    fontSize: 18,
    color: '#333',
    marginBottom: 15,
    textAlign: 'right',
  },
  formField: {
    marginBottom: 15,
  },
  fieldLabel: {
    fontFamily: 'Cairo-Bold',
    fontSize: 14,
    color: '#333',
    marginBottom: 5,
    textAlign: 'right',
  },
  textInput: {
    backgroundColor: '#f0f0f0',
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ddd',
    padding: 10,
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#333',
    textAlign: 'right',
  },
  textareaInput: {
    backgroundColor: '#f0f0f0',
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ddd',
    padding: 10,
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#333',
    textAlign: 'right',
    minHeight: 120,
  },
  analysisResultsContainer: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 20,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  analysisItem: {
    marginBottom: 15,
  },
  analysisLabel: {
    fontFamily: 'Cairo-Bold',
    fontSize: 14,
    color: '#333',
    marginBottom: 5,
    textAlign: 'right',
  },
  analysisValue: {
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#666',
    textAlign: 'right',
  },
  tagContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'flex-end',
  },
  tag: {
    backgroundColor: '#e3f2fd',
    borderRadius: 15,
    paddingHorizontal: 10,
    paddingVertical: 5,
    margin: 2,
  },
  tagText: {
    fontFamily: 'Cairo-Regular',
    fontSize: 12,
    color: '#1976d2',
  },
  lawText: {
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#666',
    marginBottom: 3,
    textAlign: 'right',
  },
  recommendedLawyersContainer: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 20,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  disclaimerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
  },
  disclaimerText: {
    fontFamily: 'Cairo-Regular',
    fontSize: 12,
    color: '#666',
    marginRight: 5,
    flex: 1,
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffebee',
    padding: 10,
    marginBottom: 15,
    borderRadius: 5,
  },
  errorText: {
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#f44336',
    marginRight: 10,
    flex: 1,
  },
  loadingContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  loadingText: {
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#666',
    marginTop: 10,
  },
  emptyStateContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  emptyStateText: {
    fontFamily: 'Cairo-Regular',
    fontSize: 14,
    color: '#666',
    marginTop: 10,
    textAlign: 'center',
  },
});

export default SmartConsultationRouter;
